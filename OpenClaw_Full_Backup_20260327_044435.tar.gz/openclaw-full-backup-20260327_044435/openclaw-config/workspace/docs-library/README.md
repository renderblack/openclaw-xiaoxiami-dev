# OpenClaw 文档库

本目录保存从OpenClaw官方文档（https://docs.openclaw.ai）整理的关键信息，作为后续开发的主要参考资料。

## 目录结构

- `overview.md` - OpenClaw概述和核心概念
- `installation.md` - 安装和配置指南
- `channels.md` - 聊天通道配置（Telegram、Discord、WhatsApp等）
- `automation.md` - 自动化功能（Cron、心跳、工作流）
- `skills.md` - 技能开发指南
- `memory-system.md` - 内存系统和工作空间管理
- `api-reference.md` - API参考
- `troubleshooting.md` - 故障排除指南
- `best-practices.md` - 最佳实践（部署、开发、运维）

## 文档来源
- 官方文档网站：https://docs.openclaw.ai
- GitHub仓库：https://github.com/openclaw/openclaw
- 社区Discord：https://discord.com/invite/clawd

## 更新记录
- 2026-03-26：初始创建，基于官方文档整理

## 使用说明
此文档库用于快速查阅OpenClaw开发相关信息，建议定期更新以保持与官方文档同步。