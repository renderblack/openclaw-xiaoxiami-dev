---
name: git-manager
description: Git操作自动化 - 提交、推送、查看状态、创建分支。触发词：git提交、git推送、git状态、创建分支、提交代码
---

# Git Manager

帮助管理Git仓库的常用操作。

## 常用命令

### 查看状态
```bash
git status
git status -s
git diff
```

### 提交更改
```bash
git add -A
git commit -m "提交信息"
```

### 推送
```bash
git push
git push origin <分支名>
```

### 分支操作
```bash
git branch -a
git checkout <分支名>
git checkout -b <新分支名>
```

### 日志
```bash
git log --oneline -10
git log --graph --oneline
```

## 工作流程

1. 先执行 `git status` 查看更改
2. 用 `git diff` 确认具体修改
3. `git add -A` 暂存所有更改
4. 写明 commit 信息（简短描述）
5. `git push` 推送到远程

## 注意事项

- 提交前检查 `git status` 避免提交不必要的文件
- commit 信息要有意义，方便回溯
- 推送前确认分支正确