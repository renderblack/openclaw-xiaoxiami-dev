---
name: system-monitor
description: 系统监控 - CPU、内存、磁盘、网络监控。触发词：系统状态、查看资源、磁盘使用、内存监控
---

# System Monitor

实时监控系统资源状态。

## 快速检查

### 整体状态（一行）
```bash
echo "CPU: $(top -bn1 | grep Cpu | awk '{print $2}')% | MEM: $(free -h | awk '/Mem:/ {print $3 "/" $2}') | DISK: $(df -h / | awk 'NR==2 {print $5}')"
```

### CPU
```bash
top -bn1 | head -5
# 或
uptime
```

### 内存
```bash
free -h
```

### 磁盘
```bash
df -h
```

### 进程（按CPU排序）
```bash
ps aux --sort=-%cpu | head -10
```

### 网络
```bash
ss -tunp
# 或
netstat -tunp
```

## 监控建议

- CPU持续 > 80%：检查异常进程
- 内存使用 > 90%：注意可能OOM
- 磁盘使用 > 85%：清理日志或备份

## OpenClaw特定

检查OpenClaw服务：
```bash
ps aux | grep openclaw
```