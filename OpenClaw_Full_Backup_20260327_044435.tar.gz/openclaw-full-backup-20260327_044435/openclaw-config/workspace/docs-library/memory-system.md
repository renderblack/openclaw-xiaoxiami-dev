# 内存系统和工作空间管理

OpenClaw的内存系统和工作空间机制为AI助手提供了持久化存储和上下文管理能力。

## 工作空间概述

### 什么是工作空间？

工作空间是OpenClaw助手的"家"，包含：
- 配置文件
- 内存文件
- 技能数据
- 用户数据
- 临时文件

### 默认工作空间位置

```
~/.openclaw/workspace/
├── AGENTS.md          # 助手工作指南
├── SOUL.md           # 助手个性定义
├── USER.md           # 用户信息
├── MEMORY.md         # 长期记忆
├── TOOLS.md          # 工具配置
├── HEARTBEAT.md      # 心跳任务
├── IDENTITY.md       # 身份信息
├── BOOTSTRAP.md      # 启动脚本（首次运行后删除）
└── memory/           # 每日记忆文件
    ├── 2026-03-26.md
    ├── 2026-03-25.md
    └── ...
```

## 内存系统架构

### 1. 内存层次结构

```
┌─────────────────┐
│   会话内存      │ ← 当前会话的临时记忆
│   (易失)        │
├─────────────────┤
│   每日记忆      │ ← 按日期组织的详细记录
│   (memory/*.md) │
├─────────────────┤
│   长期记忆      │ ← 精选的重要信息
│   (MEMORY.md)   │
└─────────────────┘
```

### 2. 内存文件类型

#### 长期记忆 (MEMORY.md)
- **位置**: 工作空间根目录
- **内容**: 精选的重要信息、决策、偏好
- **加载**: 仅在主会话中加载（安全考虑）
- **更新**: 定期从每日记忆中提炼

#### 每日记忆 (memory/YYYY-MM-DD.md)
- **位置**: `memory/` 目录
- **内容**: 当天的详细活动记录
- **创建**: 每天自动创建新文件
- **用途**: 原始日志，供长期记忆提炼

#### 项目记忆
- **位置**: `memory/projects/` 或特定目录
- **内容**: 特定项目的上下文信息
- **管理**: 按项目组织，便于检索

## 内存管理最佳实践

### 1. 内存写入原则

#### 写什么？
- **重要决策**: 配置变更、架构选择
- **用户偏好**: 用户习惯、常用命令
- **学习成果**: 解决问题的经验
- **待办事项**: 需要后续处理的任务
- **错误教训**: 避免重复犯错

#### 不写什么？
- **敏感信息**: 密码、密钥、个人数据
- **临时数据**: 会话中的临时计算
- **冗余信息**: 已经记录过的内容

### 2. 内存组织策略

#### 按时间组织
```
memory/
├── 2026-03-26.md    # 今天
├── 2026-03-25.md    # 昨天
├── 2026-03-24.md    # 前天
└── archive/         # 归档（超过30天）
```

#### 按项目组织
```
memory/
├── projects/
│   ├── openclaw-dev.md
│   ├── home-automation.md
│   └── learning-notes.md
├── people/
│   ├── user-preferences.md
│   └── contact-info.md
└── systems/
    ├── backup-config.md
    └── monitoring-setup.md
```

### 3. 内存维护流程

#### 每日维护
1. 创建当天的记忆文件
2. 记录重要事件和决策
3. 更新待办事项状态

#### 每周维护
1. 回顾过去一周的记忆
2. 提炼重要信息到长期记忆
3. 清理过时的临时文件

#### 每月维护
1. 归档旧记忆文件
2. 优化内存文件结构
3. 验证备份完整性

## 工作空间管理

### 1. 工作空间初始化

```bash
# 初始化新工作空间
openclaw init --workspace /path/to/workspace

# 使用现有工作空间
openclaw --workspace /path/to/workspace
```

### 2. 工作空间配置

#### 基本配置
```json
{
  "workspace": {
    "path": "/home/openclaw/.openclaw/workspace",
    "autoCreate": true,
    "backupEnabled": true,
    "backupSchedule": "0 2 * * *"
  }
}
```

#### 内存配置
```json
{
  "memory": {
    "dailyPath": "memory/YYYY-MM-DD.md",
    "longTermPath": "MEMORY.md",
    "retentionDays": 30,
    "autoArchive": true,
    "searchEnabled": true
  }
}
```

### 3. 工作空间操作

#### 查看工作空间状态
```bash
# 查看工作空间信息
openclaw workspace info

# 列出工作空间文件
openclaw workspace ls

# 检查工作空间健康
openclaw workspace health
```

#### 管理工作空间
```bash
# 备份工作空间
openclaw workspace backup

# 恢复工作空间
openclaw workspace restore --backup backup.tar.gz

# 清理工作空间
openclaw workspace cleanup --older-than 30d
```

## 内存检索和搜索

### 1. 内存搜索工具

OpenClaw提供内置的内存搜索功能：

```bash
# 搜索内存内容
openclaw memory search "备份配置"

# 查看特定日期的记忆
openclaw memory get --date 2026-03-26

# 导出记忆内容
openclaw memory export --format json --output memories.json
```

### 2. 编程式内存访问

在技能中访问内存：

```javascript
// 示例：在技能中搜索内存
const searchResults = await memorySearch("用户偏好");
const memoryContent = await memoryGet("MEMORY.md", { from: 10, lines: 20 });
```

### 3. 语义搜索

内存系统支持语义搜索，可以理解查询的意图：

```
查询："上次备份是什么时候？"
→ 搜索："备份"、"时间"、"最近"等关键词
→ 返回：相关的记忆片段
```

## 内存安全考虑

### 1. 隐私保护

- **主会话隔离**: MEMORY.md仅在主会话加载
- **组聊限制**: 不在群组中加载个人记忆
- **数据最小化**: 只记录必要信息
- **加密选项**: 支持内存文件加密

### 2. 访问控制

```json
{
  "memory": {
    "accessControl": {
      "allowRead": ["main", "isolated"],
      "allowWrite": ["main"],
      "requireAuth": true,
      "auditLog": true
    }
  }
}
```

### 3. 数据清理

```bash
# 清理敏感数据
openclaw memory sanitize --pattern "*password*"

# 匿名化记忆
openclaw memory anonymize --input memories.md --output anonymous.md

# 永久删除
openclaw memory purge --older-than 365d --confirm
```

## 性能优化

### 1. 内存文件优化

#### 文件大小控制
- 单个记忆文件不超过100KB
- 定期分割大文件
- 使用压缩存储

#### 索引优化
```json
{
  "memory": {
    "indexing": {
      "enabled": true,
      "interval": "daily",
      "maxIndexSize": 1000000
    }
  }
}
```

### 2. 搜索性能

- 建立内存索引加速搜索
- 缓存常用查询结果
- 分页加载大量结果

## 备份和恢复

### 1. 内存备份策略

```json
{
  "backup": {
    "memory": {
      "schedule": "0 2 * * *",
      "retention": 7,
      "compression": "gzip",
      "encryption": false
    }
  }
}
```

### 2. 备份命令

```bash
# 备份内存系统
openclaw memory backup --output memory-backup-$(date +%Y%m%d).tar.gz

# 恢复内存
openclaw memory restore --backup memory-backup-20260326.tar.gz

# 验证备份
openclaw memory verify --backup memory-backup-20260326.tar.gz
```

### 3. 灾难恢复

```bash
# 完整恢复流程
1. 停止OpenClaw服务
2. 恢复工作空间备份
3. 恢复内存备份
4. 验证数据完整性
5. 启动OpenClaw服务
```

## 集成和扩展

### 1. 与技能集成

技能可以读写内存：

```markdown
# 记忆增强技能

## 功能
- 自动记录技能使用历史
- 提取技能使用模式
- 基于记忆优化技能行为

## 内存操作
- 读取：获取用户偏好
- 写入：记录技能使用
- 更新：优化技能配置
```

### 2. 外部系统集成

```json
{
  "integrations": {
    "notion": {
      "enabled": true,
      "syncMemory": true,
      "databaseId": "memory-db-id"
    },
    "obsidian": {
      "enabled": true,
      "vaultPath": "~/obsidian-vault",
      "syncSchedule": "0 4 * * *"
    }
  }
}
```

### 3. 自定义内存格式

支持自定义内存格式：

```json
{
  "memory": {
    "formats": {
      "default": "markdown",
      "custom": {
        "json": {
          "template": "memory/json-template.json",
          "parser": "custom-json-parser.js"
        },
        "yaml": {
          "template": "memory/yaml-template.yaml",
          "parser": "custom-yaml-parser.js"
        }
      }
    }
  }
}
```

## 监控和告警

### 1. 内存使用监控

```bash
# 监控内存使用
openclaw memory stats

# 查看内存增长趋势
openclaw memory trends --days 30

# 检查内存健康
openclaw memory health
```

### 2. 告警配置

```json
{
  "alerts": {
    "memory": {
      "maxSize": 104857600,  # 100MB
      "growthRate": 10485760, # 10MB/天
      "fragmentation": 0.3,   # 30%
      "notifyChannels": ["telegram", "email"]
    }
  }
}
```

### 3. 性能指标

监控关键指标：
- 内存文件数量
- 总内存大小
- 搜索响应时间
- 读写操作频率
- 错误率

## 最佳实践总结

### 1. 日常使用
- 每次会话开始时读取相关记忆
- 重要决策立即记录
- 定期回顾和提炼记忆

### 2. 维护管理
- 定期备份内存
- 清理过时记忆
- 优化内存结构

### 3. 安全隐私
- 保护敏感信息
- 控制访问权限
- 审计内存访问

### 4. 性能优化
- 控制文件大小
- 建立有效索引
- 监控使用模式

通过合理使用内存系统和工作空间，OpenClaw助手可以保持上下文连续性，提供更加个性化和智能的服务。