---
name: file-organizer
description: 文件整理 - 按类型分类、清理临时文件、归档管理。触发词：整理文件、清理临时、归档文件、分类
---

# File Organizer

帮助整理和清理文件。

## 按类型分类

### 常用文件类型映射
| 类型 | 扩展名 |
|------|--------|
| 文档 | .md, .txt, .pdf, .doc |
| 代码 | .js, .ts, .py, .sh, .json |
| 图片 | .jpg, .png, .gif, .webp |
| 压缩 | .zip, .tar, .gz, .7z |
| 日志 | .log, .jsonl |

### 分类脚本示例
```bash
# 按扩展名移动文件
for ext in md txt json; do
  mkdir -p "$ext"
  mv *.$ext "$ext/" 2>/dev/null
done
```

## 清理临时文件

### 常见临时文件
```bash
# 删除临时文件
rm -f *~ .*~
rm -f *.tmp *.temp

# 清理空目录
find . -type d -empty -delete

# 清理n天前的文件
find . -type f -mtime +30 -delete
```

### 特定目录清理
```bash
# 清理npm缓存
rm -rf node_modules/.cache

# 清理日志（保留7天）
find logs -name "*.log" -mtime +7 -delete
```

## 归档管理

### 打包
```bash
# 打包目录
tar -czf backup.tar.gz folder/

# 按日期打包
tar -czf "backup_$(date +%Y%m%d).tar.gz" folder/
```

### 解压
```bash
tar -xzf file.tar.gz
unzip file.zip
```

## 安全提醒

- 删除前确认文件不重要
- 使用 `trash` 而非 `rm`（如果配置了别名）
- 重要文件先备份再清理