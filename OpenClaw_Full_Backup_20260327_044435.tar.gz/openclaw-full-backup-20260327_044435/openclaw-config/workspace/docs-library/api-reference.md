# API 参考

OpenClaw提供多种API接口，包括REST API、WebSocket和命令行接口。

## REST API

### 基础信息

- **基础URL**: `http://localhost:3000/api` (默认端口)
- **认证**: Bearer Token 或 API Key
- **格式**: JSON

### 认证

#### 获取访问令牌

```http
POST /auth/token
Content-Type: application/json

{
  "username": "admin",
  "password": "password"
}
```

响应：
```json
{
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "expiresIn": 3600
}
```

#### 使用令牌

```http
GET /api/status
Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

### 系统状态

#### 获取系统状态

```http
GET /api/status
```

响应：
```json
{
  "version": "2026.3.13",
  "uptime": 123456,
  "memory": {
    "used": 256,
    "total": 1024,
    "percentage": 25
  },
  "disk": {
    "used": 27,
    "total": 225,
    "percentage": 12
  },
  "services": {
    "gateway": "running",
    "database": "connected",
    "cache": "healthy"
  }
}
```

#### 健康检查

```http
GET /api/health
```

响应：
```json
{
  "status": "healthy",
  "checks": {
    "database": "ok",
    "cache": "ok",
    "storage": "ok",
    "network": "ok"
  }
}
```

### 会话管理

#### 获取会话列表

```http
GET /api/sessions
```

响应：
```json
{
  "sessions": [
    {
      "id": "session-123",
      "type": "main",
      "createdAt": "2026-03-26T05:00:00Z",
      "lastActivity": "2026-03-26T05:30:00Z",
      "user": "1022202630",
      "channel": "telegram"
    }
  ],
  "total": 1
}
```

#### 获取会话详情

```http
GET /api/sessions/{sessionId}
```

响应：
```json
{
  "id": "session-123",
  "type": "main",
  "createdAt": "2026-03-26T05:00:00Z",
  "lastActivity": "2026-03-26T05:30:00Z",
  "user": "1022202630",
  "channel": "telegram",
  "messages": [
    {
      "id": "msg-1",
      "role": "user",
      "content": "你好",
      "timestamp": "2026-03-26T05:00:00Z"
    },
    {
      "id": "msg-2",
      "role": "assistant",
      "content": "你好！有什么可以帮助你的？",
      "timestamp": "2026-03-26T05:00:01Z"
    }
  ]
}
```

#### 发送消息

```http
POST /api/sessions/{sessionId}/messages
Content-Type: application/json

{
  "message": "查询天气",
  "channel": "telegram"
}
```

响应：
```json
{
  "id": "msg-3",
  "role": "assistant",
  "content": "请问要查询哪个城市的天气？",
  "timestamp": "2026-03-26T05:31:00Z"
}
```

### 技能管理

#### 获取技能列表

```http
GET /api/skills
```

响应：
```json
{
  "skills": [
    {
      "id": "weather",
      "name": "天气查询",
      "description": "查询天气信息",
      "enabled": true,
      "version": "1.0.0"
    },
    {
      "id": "file-manager",
      "name": "文件管理",
      "description": "管理本地文件",
      "enabled": true,
      "version": "1.2.0"
    }
  ]
}
```

#### 执行技能

```http
POST /api/skills/{skillId}/execute
Content-Type: application/json

{
  "input": "北京天气",
  "parameters": {
    "city": "北京",
    "format": "json"
  }
}
```

响应：
```json
{
  "success": true,
  "result": {
    "city": "北京",
    "temperature": "15°C",
    "condition": "晴朗",
    "humidity": "45%"
  },
  "executionTime": 1200
}
```

### 任务管理

#### 获取Cron任务列表

```http
GET /api/cron/jobs
```

响应：
```json
{
  "jobs": [
    {
      "id": "job-123",
      "name": "每日备份",
      "schedule": "0 2 * * *",
      "enabled": true,
      "lastRun": "2026-03-26T02:00:00Z",
      "nextRun": "2026-03-27T02:00:00Z"
    }
  ]
}
```

#### 创建Cron任务

```http
POST /api/cron/jobs
Content-Type: application/json

{
  "name": "健康检查",
  "schedule": {
    "kind": "cron",
    "expr": "0 */2 * * *"
  },
  "payload": {
    "kind": "agentTurn",
    "message": "检查系统健康状态"
  },
  "enabled": true
}
```

响应：
```json
{
  "id": "job-456",
  "createdAt": "2026-03-26T05:32:00Z",
  "status": "active"
}
```

#### 触发任务执行

```http
POST /api/cron/jobs/{jobId}/run
```

响应：
```json
{
  "runId": "run-789",
  "startedAt": "2026-03-26T05:33:00Z",
  "status": "running"
}
```

### 内存管理

#### 搜索内存

```http
POST /api/memory/search
Content-Type: application/json

{
  "query": "备份配置",
  "limit": 10
}
```

响应：
```json
{
  "results": [
    {
      "path": "MEMORY.md",
      "lines": "15-20",
      "content": "备份配置：每日凌晨2点执行完整备份",
      "score": 0.95
    },
    {
      "path": "memory/2026-03-25.md",
      "lines": "45-50",
      "content": "更新备份脚本，修复时间戳格式问题",
      "score": 0.82
    }
  ],
  "total": 2
}
```

#### 写入内存

```http
POST /api/memory/write
Content-Type: application/json

{
  "path": "memory/2026-03-26.md",
  "content": "2026-03-26 05:35: 配置API文档库",
  "append": true
}
```

响应：
```json
{
  "success": true,
  "bytesWritten": 45,
  "path": "memory/2026-03-26.md"
}
```

## WebSocket API

### 连接建立

```javascript
const ws = new WebSocket('ws://localhost:3000/ws');

ws.onopen = () => {
  console.log('WebSocket连接已建立');
  
  // 认证
  ws.send(JSON.stringify({
    type: 'auth',
    token: 'your-token-here'
  }));
  
  // 订阅会话
  ws.send(JSON.stringify({
    type: 'subscribe',
    channel: 'session:main'
  }));
};

ws.onmessage = (event) => {
  const data = JSON.parse(event.data);
  console.log('收到消息:', data);
};
```

### 消息类型

#### 认证消息
```json
{
  "type": "auth",
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
}
```

#### 订阅消息
```json
{
  "type": "subscribe",
  "channel": "session:main"
}
```

#### 取消订阅
```json
{
  "type": "unsubscribe",
  "channel": "session:main"
}
```

#### 发送消息
```json
{
  "type": "message",
  "channel": "session:main",
  "content": "你好，助手"
}
```

#### 接收消息
```json
{
  "type": "message",
  "channel": "session:main",
  "content": "你好！有什么可以帮助你的？",
  "timestamp": "2026-03-26T05:40:00Z",
  "sender": "assistant"
}
```

#### 系统事件
```json
{
  "type": "system",
  "event": "session_started",
  "data": {
    "sessionId": "session-123",
    "userId": "1022202630"
  }
}
```

### 事件通道

可订阅的通道：
- `session:main` - 主会话消息
- `session:{id}` - 特定会话消息
- `system:events` - 系统事件
- `cron:runs` - Cron任务执行
- `skills:execution` - 技能执行

## 命令行接口 (CLI)

### 系统命令

#### 查看状态
```bash
openclaw status
```

#### 查看版本
```bash
openclaw --version
```

#### 查看帮助
```bash
openclaw help
openclaw help <command>
```

### 服务管理

#### 启动服务
```bash
openclaw start
```

#### 停止服务
```bash
openclaw stop
```

#### 重启服务
```bash
openclaw restart
```

#### 查看日志
```bash
openclaw logs
openclaw logs --follow
openclaw logs --tail 100
```

### 通道管理

#### 查看通道状态
```bash
openclaw channels status
```

#### 测试通道
```bash
openclaw channels test --channel telegram
```

#### 发送消息
```bash
openclaw channels send \
  --channel telegram \
  --to "1022202630" \
  --message "测试消息"
```

### 技能管理

#### 列出技能
```bash
openclaw skills list
```

#### 启用/禁用技能
```bash
openclaw skills enable weather
openclaw skills disable weather
```

#### 执行技能
```bash
openclaw skills execute weather --input "北京天气"
```

### 任务管理

#### 列出Cron任务
```bash
openclaw cron list
```

#### 创建任务
```bash
openclaw cron add --file task.json
```

#### 运行任务
```bash
openclaw cron run --jobId "job-123"
```

#### 删除任务
```bash
openclaw cron remove --jobId "job-123"
```

### 内存管理

#### 搜索内存
```bash
openclaw memory search "备份"
```

#### 查看记忆
```bash
openclaw memory get --date 2026-03-26
```

#### 写入记忆
```bash
openclaw memory write --content "记录重要事件" --date today
```

### 工作空间管理

#### 查看工作空间信息
```bash
openclaw workspace info
```

#### 备份工作空间
```bash
openclaw workspace backup
```

#### 恢复工作空间
```bash
openclaw workspace restore --backup backup.tar.gz
```

## SDK 和客户端库

### JavaScript/TypeScript SDK

#### 安装
```bash
npm install @openclaw/sdk
```

#### 使用示例
```javascript
import { OpenClawClient } from '@openclaw/sdk';

const client = new OpenClawClient({
  baseUrl: 'http://localhost:3000',
  apiKey: 'your-api-key'
});

// 发送消息
const response = await client.sendMessage({
  sessionId: 'main',
  message: '你好',
  channel: 'telegram'
});

// 执行技能
const result = await client.executeSkill({
  skillId: 'weather',
  input: '北京天气'
});

// 管理任务
const jobs = await client.listCronJobs();
```

### Python SDK

#### 安装
```bash
pip install openclaw-sdk
```

#### 使用示例
```python
from openclaw import OpenClawClient

client = OpenClawClient(
    base_url="http://localhost:3000",
    api_key="your-api-key"
)

# 发送消息
response = client.send_message(
    session_id="main",
    message="你好",
    channel="telegram"
)

# 执行技能
result = client.execute_skill(
    skill_id="weather",
    input="北京天气"
)

# 管理任务
jobs = client.list_cron_jobs()
```

### Go SDK

#### 安装
```bash
go get github.com/openclaw/go-sdk
```

#### 使用示例
```go
package main

import (
    "context"
    "fmt"
    "github.com/openclaw/go-sdk"
)

func main() {
    client := openclaw.NewClient(
        openclaw.WithBaseURL("http://localhost:3000"),
        openclaw.WithAPIKey("your-api-key"),
    )
    
    // 发送消息
    resp, err := client.SendMessage(context.Background(), &openclaw.SendMessageRequest{
        SessionID: "main",
        Message:   "你好",
        Channel:   "telegram",
    })
    
    if err != nil {
        panic(err)
    }
    
    fmt.Printf("响应: %v\n", resp)
}
```

## 错误处理

### 错误响应格式

```json
{
  "error": {
    "code": "INVALID_INPUT",
    "message": "输入参数无效",
    "details": {
      "field": "city",
      "reason": "城市名称不能为空"
    },
    "timestamp": "2026-03-26T05:45:00Z"
  }
}
```

### 常见错误代码

| 代码 | 描述 | HTTP状态码 |
|------|------|------------|
| `UNAUTHORIZED` | 未授权访问 | 401 |
| `FORBIDDEN` | 权限不足 | 403 |
| `NOT_FOUND` | 资源不存在 | 404 |
| `INVALID_INPUT` | 输入参数无效 | 400 |
| `RATE_LIMITED` | 请求频率超限 | 429 |
| `INTERNAL_ERROR` | 服务器内部错误 | 500 |
| `SERVICE_UNAVAILABLE` | 服务不可用 | 503 |

### 重试策略

```javascript
// 示例：带退避的重试逻辑
async function callWithRetry(apiCall, maxRetries = 3) {
  let lastError;
  
  for (let i = 0; i < maxRetries; i++) {
    try {
      return await apiCall();
    } catch (error) {
      lastError = error;
      
      // 如果是可重试错误
      if (error.code === 'RATE_LIMITED' || error.code === 'SERVICE_UNAVAILABLE') {
        // 指数退避
        const delay = Math.pow(2, i) * 1000;
        await new Promise(resolve => setTimeout(resolve, delay));
        continue;
      }
      
      // 不可重试错误
      throw error;
    }
  }
  
  throw lastError;
}
```

## 速率限制

### 默认限制

- **认证用户**: 1000 请求/小时
- **匿名用户**: 100 请求/小时
- **WebSocket连接**: 10 连接/IP

### 查看限制

```http
GET /api/rate-limit
```

响应：
```json
{
  "limits": {
    "hourly": 1000,
    "used": 150,
    "remaining": 850,
    "reset": "2026-03-26T06:00:00Z"
  }
}
```

### 限制头信息

响应头包含速率限制信息：
```
X-RateLimit-Limit: 1000
X-RateLimit-Remaining: 850
X-RateLimit-Reset: 1742976000
Retry-After: 900
```

## 版本控制

### API版本

API版本通过URL路径或请求头指定：

```http
GET /api/v1/status
```

或

```http
GET /api/status
Accept: application/vnd.openclaw.v1+json
```

### 弃用策略

- 旧版本API至少支持6个月
- 弃用通知提前3个月发布
- 提供迁移指南和工具

## 监控和指标

### 健康端点

```http
GET /health
GET /ready
GET /live
```

### 指标端点

```http
GET /metrics
```

响应格式（Prometheus）：
```
# HELP openclaw_requests_total Total number of requests
# TYPE openclaw_requests_total counter
openclaw_requests_total{method="GET",path="/api/status",status="200"} 123

# HELP openclaw_response_time_seconds Response time in seconds
# TYPE openclaw_response_time_seconds histogram
openclaw_response_time_seconds_bucket{le="0.1"} 100
openclaw_response_time_seconds_bucket{le="0.5"} 150
openclaw_response_time_seconds_bucket{le="1"} 200
```

### 跟踪支持

支持OpenTelemetry跟踪：
- 通过 `traceparent` 头传递跟踪上下文
- 导出到Jaeger、Zipkin等后端
- 支持分布式跟踪