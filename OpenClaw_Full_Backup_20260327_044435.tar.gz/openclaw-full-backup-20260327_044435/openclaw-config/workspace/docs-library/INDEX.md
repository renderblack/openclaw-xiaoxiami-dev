# OpenClaw 文档索引

快速导航和文档间的交叉引用。

## 快速入门

| 任务 | 文档 | 章节 |
|------|------|------|
| 首次安装 | [installation.md](./installation.md) | 安装方法 |
| 基本配置 | [installation.md](./installation.md) | 初始配置 |
| 连接通道 | [channels.md](./channels.md) | Telegram/Discord配置 |
| 运行服务 | [installation.md](./installation.md) | 启动和运行 |

## 核心功能

| 功能 | 文档 | 章节 |
|------|------|------|
| 定时任务 | [automation.md](./automation.md) | Cron任务系统 |
| 定期检查 | [automation.md](./automation.md) | 心跳机制 |
| 技能开发 | [skills.md](./skills.md) | 创建新技能 |
| 消息路由 | [channels.md](./channels.md) | 消息路由 |

## 高级主题

| 主题 | 文档 | 章节 |
|------|------|------|
| 自动化工作流 | [automation.md](./automation.md) | 工作流编排 |
| 自定义技能 | [skills.md](./skills.md) | 技能开发 |
| API集成 | [api-reference.md](./api-reference.md) | REST API |
| 内存管理 | [memory-system.md](./memory-system.md) | 记忆系统 |

## 运维支持

| 需求 | 文档 | 章节 |
|------|------|------|
| 故障排查 | [troubleshooting.md](./troubleshooting.md) | 常见问题 |
| 性能优化 | [best-practices.md](./best-practices.md) | 性能优化 |
| 安全配置 | [best-practices.md](./best-practices.md) | 安全实践 |
| 备份恢复 | [best-practices.md](./best-practices.md) | 备份和恢复 |

## 版本信息

- **当前版本**: OpenClaw 2026.3.13+
- **文档更新**: 2026-03-26
- **维护者**: 小龙虾🦐

## 贡献指南

欢迎贡献文档！请遵循以下原则：

1. **使用Markdown格式**
2. **包含实际示例**
3. **保持简洁清晰**
4. **标注版本兼容性**

---

*建议按顺序阅读：overview → installation → channels → automation → skills*