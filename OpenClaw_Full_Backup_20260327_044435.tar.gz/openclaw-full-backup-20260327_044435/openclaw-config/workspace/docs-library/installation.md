# OpenClaw 安装和配置指南

## 安装方法

### 方法1：使用npm全局安装（推荐）

```bash
# 安装OpenClaw
npm install -g openclaw

# 验证安装
openclaw --version
```

### 方法2：从源码安装

```bash
# 克隆仓库
git clone https://github.com/openclaw/openclaw.git
cd openclaw

# 安装依赖
npm install

# 构建项目
npm run build

# 链接到全局
npm link
```

### 方法3：使用Docker

```bash
# 拉取镜像
docker pull ghcr.io/openclaw/openclaw:latest

# 运行容器
docker run -d \
  --name openclaw \
  -p 3000:3000 \
  -v ./openclaw-data:/data \
  ghcr.io/openclaw/openclaw:latest
```

## 初始配置

### 1. 初始化工作空间

```bash
# 创建配置文件目录
mkdir -p ~/.openclaw

# 初始化配置
openclaw init
```

### 2. 基本配置文件

配置文件位置：`~/.openclaw/config.json`

```json
{
  "gateway": {
    "port": 3000,
    "host": "0.0.0.0"
  },
  "agents": {
    "default": {
      "model": "openai:gpt-4",
      "temperature": 0.7
    }
  },
  "channels": {
    "telegram": {
      "enabled": false,
      "token": "YOUR_BOT_TOKEN"
    }
  }
}
```

### 3. 环境变量配置

创建 `.env` 文件：

```bash
# 模型API密钥
OPENAI_API_KEY=sk-...
ANTHROPIC_API_KEY=sk-ant-...
DEEPSEEK_API_KEY=sk-...

# 其他配置
OPENCLAW_WORKSPACE=/path/to/workspace
OPENCLAW_LOG_LEVEL=info
```

## 通道配置

### Telegram 配置

1. 通过 @BotFather 创建机器人
2. 获取API令牌
3. 更新配置文件：

```json
{
  "channels": {
    "telegram": {
      "enabled": true,
      "token": "YOUR_BOT_TOKEN",
      "allowedUsers": ["123456789"]
    }
  }
}
```

### Discord 配置

1. 在Discord开发者门户创建应用
2. 获取客户端ID和令牌
3. 生成OAuth2 URL邀请机器人

```json
{
  "channels": {
    "discord": {
      "enabled": true,
      "token": "YOUR_DISCORD_TOKEN",
      "clientId": "YOUR_CLIENT_ID"
    }
  }
}
```

## 模型配置

### 支持的模型提供商

```json
{
  "agents": {
    "default": {
      "model": "openai:gpt-4",
      "apiKey": "${OPENAI_API_KEY}"
    },
    "claude": {
      "model": "anthropic:claude-3-opus",
      "apiKey": "${ANTHROPIC_API_KEY}"
    },
    "deepseek": {
      "model": "deepseek:deepseek-chat",
      "apiKey": "${DEEPSEEK_API_KEY}"
    }
  }
}
```

### 自定义API端点

```json
{
  "agents": {
    "custom": {
      "model": "custom-api:my-model",
      "apiKey": "custom-key",
      "baseUrl": "https://api.example.com/v1"
    }
  }
}
```

## 安全配置

### 1. 用户访问控制

```json
{
  "security": {
    "allowedUsers": ["1022202630"],
    "requireAuth": true,
    "rateLimit": {
      "maxRequests": 100,
      "windowMs": 60000
    }
  }
}
```

### 2. HTTPS配置

```json
{
  "gateway": {
    "ssl": {
      "enabled": true,
      "key": "/path/to/key.pem",
      "cert": "/path/to/cert.pem"
    }
  }
}
```

## 启动和运行

### 启动服务

```bash
# 开发模式
openclaw dev

# 生产模式
openclaw start

# 作为系统服务
openclaw service install
openclaw service start
```

### 查看状态

```bash
# 查看服务状态
openclaw status

# 查看日志
openclaw logs

# 监控指标
openclaw metrics
```

## 故障排除

### 常见问题

1. **端口被占用**
   ```bash
   # 检查端口使用
   lsof -i :3000
   # 或修改配置端口
   ```

2. **API密钥错误**
   - 检查环境变量是否正确设置
   - 验证API密钥是否有权限

3. **连接问题**
   - 检查网络连接
   - 验证防火墙设置

### 调试模式

```bash
# 启用详细日志
OPENCLAW_LOG_LEVEL=debug openclaw dev

# 或修改配置文件
{
  "logLevel": "debug"
}
```

## 更新和升级

```bash
# 更新OpenClaw
npm update -g openclaw

# 检查更新
openclaw --version
openclaw check-updates
```

## 备份和恢复

### 备份配置

```bash
# 备份整个配置目录
tar -czf openclaw-backup-$(date +%Y%m%d).tar.gz ~/.openclaw
```

### 恢复配置

```bash
# 解压备份
tar -xzf openclaw-backup-20260326.tar.gz -C ~/
```