# 技能开发指南

技能是OpenClaw的核心扩展机制，允许你创建可重用的功能模块。

## 技能概述

### 什么是技能？

技能是封装特定功能的模块，可以：
- 处理特定类型的请求
- 调用外部API
- 执行系统命令
- 管理文件操作
- 提供专业领域知识

### 技能目录结构

```
~/.nvm/versions/node/v22.22.1/lib/node_modules/openclaw/skills/
├── healthcheck/          # 健康检查技能
│   ├── SKILL.md         # 技能描述和指令
│   ├── references/      # 参考文件
│   └── scripts/        # 可执行脚本
├── node-connect/        # 节点连接技能
├── skill-creator/       # 技能创建技能
└── weather/            # 天气技能
```

## 创建新技能

### 1. 技能创建步骤

#### 方法1：使用skill-creator技能

```bash
# 触发技能创建流程
openclaw skill create --name "my-skill" --description "我的自定义技能"
```

#### 方法2：手动创建

1. 创建技能目录
2. 编写SKILL.md文件
3. 添加必要的资源文件
4. 测试技能功能

### 2. SKILL.md 文件结构

```markdown
# 技能名称

## 描述
简要描述技能的功能和用途。

## 触发条件
- 当用户询问特定问题时
- 当检测到特定关键词时
- 当满足特定条件时

## 工具使用
列出技能可以使用的工具：
- read: 读取文件
- write: 写入文件
- exec: 执行命令
- web_search: 搜索网络
- 其他工具...

## 工作流程
1. 第一步：验证输入
2. 第二步：执行核心逻辑
3. 第三步：处理结果
4. 第四步：返回响应

## 配置选项
```json
{
  "apiKey": "可选API密钥",
  "endpoint": "可选端点",
  "timeout": 30000
}
```

## 示例
提供使用示例。

## 错误处理
描述如何处理常见错误。

## 依赖项
列出技能依赖的外部服务或工具。
```

## 技能开发最佳实践

### 1. 技能设计原则

#### 单一职责
每个技能应该只做一件事，并且做好。

```markdown
# 好例子：天气查询技能
- 功能：查询天气信息
- 不包含：航班查询、新闻获取

# 坏例子：万能助手技能
- 功能：天气、新闻、股票、翻译...
- 问题：职责过多，难以维护
```

#### 明确触发条件
技能应该有清晰的触发条件。

```markdown
## 触发条件
- 当用户询问"天气怎么样？"时
- 当消息包含"温度"、"天气预报"等关键词时
- 当用户明确要求"查询天气"时
```

#### 优雅的错误处理
技能应该妥善处理各种错误情况。

```markdown
## 错误处理
1. API不可用：返回友好的错误消息
2. 网络超时：建议重试
3. 无效输入：提示用户提供正确信息
4. 权限不足：提示用户检查配置
```

### 2. 工具使用规范

#### 安全使用exec
```markdown
## 安全注意事项
- 永远不要执行未经验证的用户输入
- 使用参数化命令而不是字符串拼接
- 设置适当的超时时间
- 限制命令执行权限
```

#### 文件操作规范
```markdown
## 文件操作
- 使用相对路径而不是绝对路径
- 检查文件是否存在再操作
- 备份重要文件后再修改
- 清理临时文件
```

### 3. 配置管理

#### 技能配置
```json
{
  "mySkill": {
    "enabled": true,
    "apiKey": "${MY_API_KEY}",
    "endpoint": "https://api.example.com",
    "cacheTtl": 3600,
    "retryAttempts": 3
  }
}
```

#### 环境变量
```bash
# .env文件
MY_API_KEY=sk_123456789
MY_SKILL_TIMEOUT=30000
```

## 技能示例

### 示例1：简单的文件管理技能

```markdown
# 文件管理器技能

## 描述
管理本地文件系统的技能，支持文件查看、创建、编辑和删除。

## 触发条件
- 当用户说"查看文件"、"创建文件"、"编辑文件"、"删除文件"时
- 当消息包含文件路径时

## 工具使用
- read: 读取文件内容
- write: 创建或覆盖文件
- edit: 编辑文件
- exec: 执行文件操作命令

## 工作流程
1. 解析用户请求，提取文件路径和操作类型
2. 验证文件路径安全性
3. 执行请求的文件操作
4. 返回操作结果

## 配置选项
```json
{
  "allowedPaths": ["~/.openclaw/workspace", "~/Documents"],
  "maxFileSize": 10485760,
  "backupBeforeEdit": true
}
```

## 示例
用户：查看文件 /home/user/test.txt
助手：使用read工具读取文件内容并显示

用户：创建文件 notes.md
助手：使用write工具创建文件

用户：编辑 config.json
助手：使用edit工具修改文件
```

### 示例2：API集成技能

```markdown
# GitHub集成技能

## 描述
与GitHub API集成的技能，支持仓库管理、问题跟踪等。

## 触发条件
- 当用户提到"GitHub"、"仓库"、"issue"、"PR"时
- 当用户要求管理GitHub资源时

## 工具使用
- web_fetch: 调用GitHub API
- write: 保存API响应
- exec: 执行git命令

## 工作流程
1. 验证GitHub令牌配置
2. 构建API请求
3. 发送请求并处理响应
4. 格式化结果显示给用户

## 配置选项
```json
{
  "githubToken": "${GITHUB_TOKEN}",
  "apiBaseUrl": "https://api.github.com",
  "defaultUser": "myusername",
  "timeout": 10000
}
```

## 依赖项
- GitHub个人访问令牌
- 网络连接
```

## 技能测试

### 1. 单元测试

创建测试脚本验证技能功能：

```bash
#!/bin/bash
# test-my-skill.sh

echo "测试技能：我的技能"

# 测试1：基本功能
echo "测试1：验证技能触发条件"
# 测试代码...

# 测试2：错误处理
echo "测试2：验证错误处理"
# 测试代码...

# 测试3：性能测试
echo "测试3：验证性能"
# 测试代码...

echo "测试完成"
```

### 2. 集成测试

测试技能与其他组件的集成：

```json
{
  "testCases": [
    {
      "name": "技能与通道集成",
      "input": "通过Telegram发送技能请求",
      "expected": "技能正确响应"
    },
    {
      "name": "技能与内存系统集成",
      "input": "技能访问内存文件",
      "expected": "正确读写内存"
    }
  ]
}
```

## 技能部署

### 1. 本地部署

```bash
# 将技能复制到技能目录
cp -r my-skill ~/.nvm/versions/node/v22.22.1/lib/node_modules/openclaw/skills/

# 验证技能加载
openclaw skills list
```

### 2. 配置启用

```json
{
  "skills": {
    "mySkill": {
      "enabled": true,
      "config": {
        "apiKey": "your-api-key"
      }
    }
  }
}
```

## 技能维护

### 1. 版本管理

```markdown
# 更新日志

## v1.0.0 (2026-03-26)
- 初始版本发布
- 支持基本文件操作

## v1.1.0 (2026-03-27)
- 添加错误处理
- 改进性能
- 修复安全漏洞
```

### 2. 文档更新

保持技能文档与实际功能同步：
- 更新触发条件
- 添加新功能说明
- 记录已知问题
- 提供使用示例

### 3. 性能监控

```bash
# 监控技能使用情况
openclaw skills stats

# 查看技能错误日志
openclaw skills logs --skill my-skill
```

## 高级技能开发

### 1. 技能组合

多个技能可以组合使用：

```markdown
# 数据分析技能组合

## 包含技能
1. 数据获取技能：从API获取数据
2. 数据处理技能：清洗和转换数据
3. 数据可视化技能：生成图表
4. 报告生成技能：创建分析报告

## 工作流程
用户请求数据分析 → 触发技能组合 → 按顺序执行各技能 → 返回完整结果
```

### 2. 条件技能

根据条件动态选择技能：

```json
{
  "skillRouting": {
    "rules": [
      {
        "condition": "message contains '天气'",
        "skill": "weather"
      },
      {
        "condition": "message contains '文件'",
        "skill": "file-manager"
      },
      {
        "condition": "message contains '计算'",
        "skill": "calculator"
      }
    ]
  }
}
```

### 3. 技能参数化

支持动态参数的技能：

```markdown
## 参数支持
- ${city}: 城市名称
- ${date}: 日期（YYYY-MM-DD）
- ${format}: 输出格式（json/text）

## 使用示例
用户：查询${city}的${date}天气，格式${format}
```

## 故障排除

### 常见问题

1. **技能未触发**
   - 检查触发条件配置
   - 验证技能是否启用
   - 查看技能日志

2. **权限问题**
   - 检查文件系统权限
   - 验证API令牌权限
   - 确认网络访问权限

3. **性能问题**
   - 检查技能执行时间
   - 优化资源使用
   - 添加缓存机制

### 调试技巧

```bash
# 启用技能调试模式
OPENCLAW_SKILL_DEBUG=1 openclaw dev

# 查看技能详细日志
tail -f ~/.openclaw/logs/skills.log
```

## 社区技能

### 1. 技能市场

访问 [ClawHub](https://clawhub.ai) 发现社区贡献的技能：
- 生产力工具
- 开发工具
- 娱乐技能
- 教育技能

### 2. 贡献技能

向社区贡献技能的步骤：
1. 开发并测试技能
2. 编写完整文档
3. 提交到技能仓库
4. 维护和更新

### 3. 技能评分和反馈

社区技能通常有：
- 用户评分
- 使用统计
- 问题报告
- 版本历史