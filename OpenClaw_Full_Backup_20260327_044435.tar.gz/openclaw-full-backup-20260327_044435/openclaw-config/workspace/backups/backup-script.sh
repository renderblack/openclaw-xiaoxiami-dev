#!/bin/bash

# OpenClaw 备份脚本
# 作者：小龙虾🦞
# 日期：2026-03-26

set -e

# 配置变量
BACKUP_ROOT="/home/openclaw/.openclaw/workspace/backups"
WORKSPACE_DIR="/home/openclaw/.openclaw/workspace"
CONFIG_DIR="/home/openclaw/.openclaw"
TIMESTAMP=$(date +"%Y%m%d_%H%M")
BACKUP_TYPE="${1:-daily}"  # daily, weekly, monthly

# 颜色输出
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

log_info() {
    echo -e "${GREEN}[INFO]${NC} $(date '+%Y-%m-%d %H:%M:%S') - $1"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $(date '+%Y-%m-%d %H:%M:%S') - $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $(date '+%Y-%m-%d %H:%M:%S') - $1"
}

# 检查目录
check_directories() {
    if [ ! -d "$BACKUP_ROOT" ]; then
        log_error "备份根目录不存在: $BACKUP_ROOT"
        exit 1
    fi
    
    if [ ! -d "$WORKSPACE_DIR" ]; then
        log_error "工作空间目录不存在: $WORKSPACE_DIR"
        exit 1
    fi
}

# 创建备份
create_backup() {
    local backup_dir="$BACKUP_ROOT/$BACKUP_TYPE"
    local backup_file="backup_${BACKUP_TYPE}_${TIMESTAMP}.tar.gz"
    local backup_path="$backup_dir/$backup_file"
    
    log_info "开始创建 $BACKUP_TYPE 备份..."
    
    # 创建备份目录
    mkdir -p "$backup_dir"
    
    # 创建临时目录（使用短时间戳避免文件名过长）
    local short_ts=$(date +"%y%m%d%H%M")
    local temp_dir="/tmp/bk_$short_ts"
    mkdir -p "$temp_dir"
    
    # 复制工作空间（排除备份目录自身）
    log_info "备份工作空间..."
    mkdir -p "$temp_dir/workspace"
    cp -r "$WORKSPACE_DIR"/* "$temp_dir/workspace/" 2>/dev/null || true
    # 排除备份目录自身
    rm -rf "$temp_dir/workspace/backups" 2>/dev/null || true
    
    # 复制配置文件
    log_info "备份配置文件..."
    mkdir -p "$temp_dir/config"
    cp -r "$CONFIG_DIR"/*.json "$temp_dir/config/" 2>/dev/null || true
    cp -r "$CONFIG_DIR"/*.yaml "$temp_dir/config/" 2>/dev/null || true
    cp -r "$CONFIG_DIR"/*.yml "$temp_dir/config/" 2>/dev/null || true
    
    # 备份日志目录（最近7天）
    log_info "备份日志目录..."
    mkdir -p "$temp_dir/logs"
    find "$CONFIG_DIR/logs" -type f -mtime -7 -name "*.log" -exec cp {} "$temp_dir/logs/" \; 2>/dev/null || true
    find "$CONFIG_DIR/logs" -type f -mtime -7 -name "*.jsonl" -exec cp {} "$temp_dir/logs/" \; 2>/dev/null || true
    
    # 备份日志轮转配置
    log_info "备份日志轮转配置..."
    mkdir -p "$temp_dir/log-rotation"
    cp -r "$CONFIG_DIR/log-rotation" "$temp_dir/" 2>/dev/null || true
    
    # 备份技能配置
    log_info "备份技能配置..."
    mkdir -p "$temp_dir/skills"
    SKILLS_DIR="$CONFIG_DIR/../node_modules/openclaw/skills"
    if [ -d "$SKILLS_DIR" ]; then
        # 只备份技能目录结构，不备份node_modules
        find "$SKILLS_DIR" -maxdepth 1 -type d | grep -v "node_modules" | while read -r skill_dir; do
            skill_name=$(basename "$skill_dir")
            if [ "$skill_name" != "skills" ]; then
                cp -r "$skill_dir" "$temp_dir/skills/" 2>/dev/null || true
            fi
        done
    fi
    # 也备份workspace中的技能链接配置
    if [ -d "$WORKSPACE_DIR/skills" ]; then
        cp -r "$WORKSPACE_DIR/skills" "$temp_dir/workspace/" 2>/dev/null || true
    fi
    
    # 创建备份元数据
    cat > "$temp_dir/backup_metadata.json" << EOF
{
    "backup_type": "$BACKUP_TYPE",
    "timestamp": "$TIMESTAMP",
    "created_at": "$(date -Iseconds)",
    "source_host": "$(hostname)",
    "openclaw_version": "$(openclaw --version 2>/dev/null || echo 'unknown')",
    "disk_usage": "$(df -h /home/openclaw | tail -1)"
}
EOF
    
    # 打包压缩
    log_info "打包备份文件..."
    tar -czf "$backup_path" -C "$temp_dir" .
    
    # 清理临时目录
    rm -rf "$temp_dir"
    
    # 验证备份文件
    if [ -f "$backup_path" ]; then
        local file_size=$(du -h "$backup_path" 2>/dev/null | cut -f1 || echo "unknown")
        log_info "备份创建成功: $backup_file (大小: $file_size)"
        echo "$backup_path"
    else
        log_error "备份文件创建失败"
        exit 1
    fi
}

# 清理旧备份
cleanup_old_backups() {
    local backup_dir="$BACKUP_ROOT/$BACKUP_TYPE"
    local keep_days=7
    
    case "$BACKUP_TYPE" in
        "daily")
            keep_days=7
            ;;
        "weekly")
            keep_days=28  # 4周
            ;;
        "monthly")
            keep_days=365  # 12个月
            ;;
    esac
    
    log_info "清理 $BACKUP_TYPE 备份（保留最近 $keep_days 天）..."
    
    find "$backup_dir" -name "backup_${BACKUP_TYPE}_*.tar.gz" -type f -mtime +$keep_days -delete
    
    local remaining=$(find "$backup_dir" -name "backup_${BACKUP_TYPE}_*.tar.gz" -type f | wc -l)
    log_info "清理完成，剩余备份文件: $remaining"
}

# 主函数
main() {
    log_info "=== OpenClaw 备份脚本 ==="
    log_info "备份类型: $BACKUP_TYPE"
    log_info "时间戳: $TIMESTAMP"
    
    check_directories
    
    # 创建备份
    backup_file=$(create_backup)
    
    # 清理旧备份
    cleanup_old_backups
    
    # 生成报告
    local file_size=$(du -h "$backup_file" 2>/dev/null | cut -f1 || echo "unknown")
    cat > "$BACKUP_ROOT/last_backup.log" << EOF
=== 备份完成报告 ===
时间: $(date)
类型: $BACKUP_TYPE
文件: $(basename "$backup_file")
大小: $file_size
状态: 成功
EOF
    
    log_info "备份流程完成"
}

# 执行主函数
main "$@"