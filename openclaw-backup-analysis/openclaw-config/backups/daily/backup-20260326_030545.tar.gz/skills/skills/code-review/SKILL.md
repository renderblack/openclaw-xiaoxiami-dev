---
name: code-review
description: 代码审查辅助 - 检查代码质量、查找问题、代码统计。触发词：代码审查、检查代码、代码分析
---

# Code Review

辅助代码审查和质量检查。

## 快速检查

### 文件统计
```bash
# 行数统计
wc -l *.js
# 或
find . -name "*.js" -exec wc -l {} + | tail -1
```

### 代码结构
```bash
# 目录树
tree -L 2

# 文件类型统计
find . -type f | sed 's/.*\.//' | sort | uniq -c | sort -rn
```

## 代码质量检查

### JavaScript/TypeScript
```bash
# 语法检查
node --check file.js

# ESLint（如果配置）
npx eslint .
```

### Shell脚本
```bash
# 语法检查
bash -n script.sh

# shellcheck
shellcheck script.sh
```

### JSON
```bash
# 验证JSON
cat file.json | python3 -m json.tool > /dev/null && echo "Valid"
```

## 常用检查项

1. **语法错误** - 用对应解析器检查
2. **敏感信息** - 查找密码、密钥
   ```bash
   grep -r "password\|secret\|api_key" .
   ```
3. **TODO/FIXME** - 查找待办
   ```bash
   grep -r "TODO\|FIXME\|BUG" .
   ```
4. **空文件** - 查找空文件
   ```bash
   find . -type f -empty
   ```

## Git集成

### 查看改动
```bash
# 未提交的改动
git diff

# 与上次提交对比
git diff HEAD~1

# 特定文件的改动
git diff file.js
```

### 提交前检查
```bash
git status
git diff --stat
```

## 建议

- 提交前运行 `git diff` 确认改动
- 检查是否有调试代码遗留
- 确认敏感信息未泄露