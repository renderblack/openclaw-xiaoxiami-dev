# 自动化功能

OpenClaw提供强大的自动化功能，包括定时任务、事件触发和条件执行。

## Cron 任务系统

### 1. 基本概念

Cron任务允许你在特定时间或间隔执行自动化任务，支持多种调度类型。

### 2. 调度类型

#### 一次性任务（at）

```json
{
  "schedule": {
    "kind": "at",
    "at": "2026-03-27T10:00:00Z"
  }
}
```

#### 重复任务（every）

```json
{
  "schedule": {
    "kind": "every",
    "everyMs": 3600000,  // 每小时
    "anchorMs": 0
  }
}
```

#### Cron表达式

```json
{
  "schedule": {
    "kind": "cron",
    "expr": "0 18 * * *",  // UTC时间每天18:00（北京时间凌晨2:00）
    "tz": "UTC"
  }
}
```

### 3. 任务类型

#### 系统事件任务

```json
{
  "payload": {
    "kind": "systemEvent",
    "text": "执行每日备份"
  },
  "sessionTarget": "main"
}
```

#### 独立代理任务

```json
{
  "payload": {
    "kind": "agentTurn",
    "message": "检查系统状态并报告",
    "model": "deepseek-chat",
    "timeoutSeconds": 300
  },
  "sessionTarget": "isolated"
}
```

### 4. 完整示例

```json
{
  "name": "每日备份任务",
  "schedule": {
    "kind": "cron",
    "expr": "0 2 * * *",
    "tz": "Asia/Shanghai"
  },
  "payload": {
    "kind": "agentTurn",
    "message": "执行系统备份并检查磁盘空间",
    "model": "deepseek-chat"
  },
  "delivery": {
    "mode": "announce",
    "channel": "telegram",
    "to": "1022202630"
  },
  "enabled": true
}
```

## 心跳机制

### 1. 心跳配置

心跳是定期检查系统状态的机制，可以配置检查频率和检查内容。

```json
{
  "heartbeat": {
    "enabled": true,
    "intervalMinutes": 30,
    "prompt": "检查系统状态：磁盘空间、内存使用、服务状态",
    "quietHours": {
      "start": "23:00",
      "end": "08:00"
    }
  }
}
```

### 2. 心跳任务示例

创建HEARTBEAT.md文件：

```markdown
# 心跳检查清单

## 系统检查
- [ ] 磁盘空间使用率
- [ ] 内存使用情况
- [ ] CPU负载
- [ ] 网络连接

## 服务检查
- [ ] OpenClaw服务状态
- [ ] 数据库连接
- [ ] 外部API可用性

## 业务检查
- [ ] 待处理任务
- [ ] 错误日志
- [ ] 备份状态
```

### 3. 心跳响应规则

- 发现问题时：立即通知用户
- 一切正常时：回复 `HEARTBEAT_OK`
- 夜间时段：静默模式（除非紧急）

## 事件触发

### 1. 文件系统事件

```json
{
  "triggers": [
    {
      "type": "fileChange",
      "path": "~/.openclaw/logs/*.log",
      "action": "analyzeLogs"
    },
    {
      "type": "fileCreate",
      "path": "~/Downloads/*.pdf",
      "action": "processDocument"
    }
  ]
}
```

### 2. 时间事件

```json
{
  "triggers": [
    {
      "type": "timeOfDay",
      "time": "09:00",
      "action": "sendMorningReport"
    },
    {
      "type": "dayOfWeek",
      "days": ["Monday", "Friday"],
      "action": "weeklySummary"
    }
  ]
}
```

### 3. 外部事件

```json
{
  "triggers": [
    {
      "type": "webhook",
      "endpoint": "/github-webhook",
      "action": "handleGitHubEvent"
    },
    {
      "type": "mqtt",
      "topic": "sensors/temperature",
      "action": "handleTemperatureChange"
    }
  ]
}
```

## 工作流编排

### 1. 顺序执行

```json
{
  "workflows": [
    {
      "name": "数据备份流程",
      "steps": [
        {
          "action": "backupDatabase",
          "timeout": "5m"
        },
        {
          "action": "compressBackup",
          "dependsOn": ["backupDatabase"]
        },
        {
          "action": "uploadToCloud",
          "dependsOn": ["compressBackup"]
        },
        {
          "action": "sendNotification",
          "dependsOn": ["uploadToCloud"]
        }
      ]
    }
  ]
}
```

### 2. 条件执行

```json
{
  "workflows": [
    {
      "name": "磁盘清理流程",
      "steps": [
        {
          "action": "checkDiskSpace",
          "condition": "spaceUsed > 80%"
        },
        {
          "action": "cleanTempFiles",
          "condition": "previousStep.success"
        },
        {
          "action": "sendAlert",
          "condition": "previousStep.failed"
        }
      ]
    }
  ]
}
```

## 任务管理

### 1. 查看任务列表

```bash
# 查看所有Cron任务
openclaw cron list

# 查看任务详情
openclaw cron info --jobId "job-123"

# 查看任务运行历史
openclaw cron runs --jobId "job-123"
```

### 2. 任务操作

```bash
# 创建新任务
openclaw cron add --file task.json

# 立即运行任务
openclaw cron run --jobId "job-123"

# 禁用任务
openclaw cron update --jobId "job-123" --patch '{"enabled": false}'

# 删除任务
openclaw cron remove --jobId "job-123"
```

### 3. 任务状态监控

```bash
# 查看任务状态
openclaw cron status

# 监控任务执行
openclaw cron monitor

# 查看失败任务
openclaw cron list --includeDisabled
```

## 错误处理和重试

### 1. 重试策略

```json
{
  "retry": {
    "enabled": true,
    "maxAttempts": 3,
    "backoff": {
      "strategy": "exponential",
      "initialDelay": 1000,
      "maxDelay": 10000
    },
    "retryableErrors": ["timeout", "network_error"]
  }
}
```

### 2. 错误通知

```json
{
  "errorHandling": {
    "notifyOnFailure": true,
    "notificationChannels": ["telegram", "email"],
    "escalation": {
      "afterAttempts": 3,
      "escalateTo": "admin@example.com"
    }
  }
}
```

## 性能优化

### 1. 任务调度优化

```json
{
  "scheduler": {
    "maxConcurrentJobs": 5,
    "queueSize": 100,
    "priorityLevels": ["high", "medium", "low"]
  }
}
```

### 2. 资源限制

```json
{
  "resourceLimits": {
    "memoryMb": 512,
    "timeoutSeconds": 300,
    "cpuShares": 1024
  }
}
```

## 最佳实践

### 1. 任务设计原则

1. **单一职责**：每个任务只做一件事
2. **幂等性**：任务可重复执行而不产生副作用
3. **可观测性**：任务应有清晰的日志和状态
4. **错误处理**：任务应妥善处理异常情况

### 2. 调度策略

1. **避免高峰时段**：不要在系统繁忙时运行重任务
2. **分散执行**：将相关任务分散到不同时间执行
3. **考虑时区**：明确指定任务时区
4. **设置超时**：防止任务无限期运行

### 3. 监控和告警

1. **任务成功率监控**：跟踪任务执行成功率
2. **执行时间监控**：监控任务执行时间趋势
3. **资源使用监控**：监控任务资源消耗
4. **设置告警阈值**：当指标异常时发送告警

### 4. 维护和更新

1. **定期审查任务**：清理不再需要的任务
2. **更新任务配置**：根据需求调整任务参数
3. **测试任务变更**：在非生产环境测试任务变更
4. **文档化任务**：记录任务目的和配置

## 示例用例

### 1. 系统健康检查

```json
{
  "name": "每小时健康检查",
  "schedule": {
    "kind": "every",
    "everyMs": 3600000
  },
  "payload": {
    "kind": "agentTurn",
    "message": "检查系统健康：CPU、内存、磁盘、网络、服务状态",
    "model": "deepseek-chat"
  },
  "delivery": {
    "mode": "announce",
    "channel": "telegram",
    "to": "1022202630"
  }
}
```

### 2. 每日数据备份

```json
{
  "name": "每日数据备份",
  "schedule": {
    "kind": "cron",
    "expr": "0 2 * * *",
    "tz": "Asia/Shanghai"
  },
  "payload": {
    "kind": "systemEvent",
    "text": "执行数据备份任务"
  },
  "sessionTarget": "main"
}
```

### 3. 每周报告生成

```json
{
  "name": "每周性能报告",
  "schedule": {
    "kind": "cron",
    "expr": "0 9 * * 1",
    "tz": "Asia/Shanghai"
  },
  "payload": {
    "kind": "agentTurn",
    "message": "生成上周系统性能报告，包括CPU、内存、磁盘使用情况和错误统计",
    "model": "deepseek-chat",
    "timeoutSeconds": 600
  },
  "delivery": {
    "mode": "announce",
    "channel": "discord",
    "to": "performance-reports"
  }
}
```