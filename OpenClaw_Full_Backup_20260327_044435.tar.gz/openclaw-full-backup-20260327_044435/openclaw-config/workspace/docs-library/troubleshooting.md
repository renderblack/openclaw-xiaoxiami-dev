# 故障排除指南

本文档提供OpenClaw常见问题的诊断和解决方法。

## 快速诊断

### 1. 检查服务状态

```bash
# 查看OpenClaw服务状态
openclaw status

# 查看系统日志
openclaw logs --tail 50

# 检查进程
ps aux | grep openclaw
```

### 2. 验证网络连接

```bash
# 检查端口监听
netstat -tlnp | grep :3000

# 测试本地连接
curl -v http://localhost:3000/health

# 检查外部连接
curl -v https://api.openai.com/v1/models
```

### 3. 检查配置文件

```bash
# 查看配置文件
cat ~/.openclaw/config.json | jq .

# 验证配置文件语法
openclaw config validate

# 检查环境变量
env | grep OPENCLAW
```

## 常见问题分类

### 安装问题

#### 问题1：npm安装失败

**症状**：
```
npm ERR! code EACCES
npm ERR! syscall access
npm ERR! path /usr/local/lib/node_modules
```

**解决方法**：
```bash
# 方法1：使用nvm管理Node.js版本
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.0/install.sh | bash
nvm install node
nvm use node

# 方法2：修复权限
sudo chown -R $(whoami) ~/.npm
sudo chown -R $(whoami) /usr/local/lib/node_modules

# 方法3：使用pnpm
npm install -g pnpm
pnpm add -g openclaw
```

#### 问题2：依赖安装失败

**症状**：
```
npm ERR! Could not resolve dependency
npm ERR! peer dependency missing
```

**解决方法**：
```bash
# 清理缓存并重试
npm cache clean --force
rm -rf node_modules package-lock.json
npm install

# 或使用--legacy-peer-deps
npm install --legacy-peer-deps

# 检查Node.js版本
node --version  # 需要 >= 18.0.0
```

### 启动问题

#### 问题3：端口被占用

**症状**：
```
Error: listen EADDRINUSE: address already in use :::3000
```

**解决方法**：
```bash
# 查找占用端口的进程
lsof -i :3000

# 终止占用进程
kill -9 <PID>

# 或修改配置使用其他端口
{
  "gateway": {
    "port": 3001
  }
}
```

#### 问题4：权限不足

**症状**：
```
Error: EACCES: permission denied, open '/path/to/file'
```

**解决方法**：
```bash
# 修复文件权限
sudo chown -R $(whoami) ~/.openclaw
sudo chmod -R 755 ~/.openclaw

# 或使用用户目录
mkdir -p ~/openclaw-data
openclaw --workspace ~/openclaw-data
```

### 通道问题

#### 问题5：Telegram机器人无响应

**症状**：
- 机器人不回复消息
- Webhook设置失败
- 消息发送超时

**解决方法**：
```bash
# 1. 检查机器人令牌
openclaw telegram status

# 2. 测试连接
openclaw channels test --channel telegram

# 3. 重置Webhook
openclaw telegram delete-webhook
openclaw telegram set-webhook --url https://your-domain.com/webhook

# 4. 检查防火墙
# 允许出站连接到 api.telegram.org:443
```

#### 问题6：Discord机器人无法加入服务器

**症状**：
- 邀请链接无效
- 机器人没有权限
- 消息无法发送

**解决方法**：
```bash
# 1. 重新生成邀请链接
openclaw discord invite

# 2. 检查机器人权限
# 需要以下权限：
# - 发送消息
# - 嵌入链接
# - 附加文件
# - 读取消息历史

# 3. 验证意图配置
# 在Discord开发者门户启用必要的意图：
# - GUILDS
# - GUILD_MESSAGES
# - DIRECT_MESSAGES
```

### 模型问题

#### 问题7：API密钥无效

**症状**：
```
Error: Invalid API key
Error: 401 Unauthorized
```

**解决方法**：
```bash
# 1. 验证API密钥
echo $OPENAI_API_KEY  # 或相应的环境变量

# 2. 检查密钥格式
# OpenAI: sk-...
# Anthropic: sk-ant-...
# DeepSeek: sk-...

# 3. 更新配置文件
{
  "agents": {
    "default": {
      "apiKey": "${OPENAI_API_KEY}"
    }
  }
}

# 4. 测试连接
curl -H "Authorization: Bearer $OPENAI_API_KEY" \
  https://api.openai.com/v1/models
```

#### 问题8：模型响应超时

**症状**：
```
Error: Request timeout after 30000ms
Error: Connection reset by peer
```

**解决方法**：
```json
{
  "agents": {
    "default": {
      "timeout": 60000,
      "maxRetries": 3,
      "retryDelay": 1000
    }
  }
}
```

### 技能问题

#### 问题9：技能未触发

**症状**：
- 技能不响应相关查询
- 错误消息："没有找到匹配的技能"

**解决方法**：
```bash
# 1. 检查技能状态
openclaw skills list

# 2. 启用技能
openclaw skills enable <skill-name>

# 3. 检查技能配置
cat ~/.openclaw/skills/<skill-name>/SKILL.md

# 4. 测试技能
openclaw skills execute <skill-name> --input "测试输入"
```

#### 问题10：技能执行错误

**症状**：
```
Skill execution failed: Error: Command failed
Skill execution failed: Error: File not found
```

**解决方法**：
```bash
# 1. 查看详细错误
OPENCLAW_LOG_LEVEL=debug openclaw dev

# 2. 检查技能权限
ls -la ~/.nvm/versions/node/v22.22.1/lib/node_modules/openclaw/skills/

# 3. 验证依赖
# 检查技能所需的命令是否安装
which curl
which jq
which git
```

### 内存问题

#### 问题11：内存搜索无结果

**症状**：
- 搜索返回空结果
- 相关记忆无法找到

**解决方法**：
```bash
# 1. 重建内存索引
openclaw memory reindex

# 2. 检查内存文件
ls -la ~/.openclaw/workspace/memory/

# 3. 验证搜索语法
openclaw memory search "备份"  # 关键词搜索
openclaw memory search --semantic "上次备份时间"  # 语义搜索

# 4. 检查文件权限
chmod 644 ~/.openclaw/workspace/memory/*.md
```

#### 问题12：内存写入失败

**症状**：
```
Error: EACCES: permission denied
Error: ENOSPC: no space left on device
```

**解决方法**：
```bash
# 1. 检查磁盘空间
df -h ~/.openclaw

# 2. 清理临时文件
openclaw workspace cleanup

# 3. 修复权限
sudo chown -R $(whoami) ~/.openclaw/workspace

# 4. 检查inode使用
df -i ~/.openclaw
```

### 任务问题

#### 问题13：Cron任务未执行

**症状**：
- 定时任务没有运行
- 任务状态显示为pending

**解决方法**：
```bash
# 1. 检查Cron服务状态
openclaw cron status

# 2. 查看任务列表
openclaw cron list --includeDisabled

# 3. 手动触发任务
openclaw cron run --jobId <job-id>

# 4. 检查时区配置
{
  "schedule": {
    "kind": "cron",
    "expr": "0 2 * * *",
    "tz": "Asia/Shanghai"
  }
}
```

#### 问题14：任务执行失败

**症状**：
- 任务运行但失败
- 错误日志显示执行错误

**解决方法**：
```bash
# 1. 查看任务运行历史
openclaw cron runs --jobId <job-id>

# 2. 检查任务日志
tail -f ~/.openclaw/logs/cron.log

# 3. 验证任务配置
openclaw cron info --jobId <job-id>

# 4. 测试任务命令
# 手动执行任务中的命令验证可行性
```

## 高级诊断

### 性能问题诊断

#### 症状：响应缓慢

**诊断步骤**：
```bash
# 1. 监控系统资源
top -b -n 1 | grep -E "(openclaw|node)"

# 2. 检查内存使用
free -h

# 3. 分析响应时间
OPENCLAW_LOG_LEVEL=debug openclaw dev
# 查看请求处理时间日志

# 4. 检查网络延迟
ping api.openai.com
traceroute api.openai.com
```

**优化建议**：
```json
{
  "performance": {
    "cache": {
      "enabled": true,
      "ttl": 3600,
      "maxSize": 100
    },
    "concurrency": {
      "maxRequests": 10,
      "maxSessions": 5
    },
    "compression": {
      "enabled": true,
      "level": 6
    }
  }
}
```

### 网络问题诊断

#### 症状：连接不稳定

**诊断步骤**：
```bash
# 1. 测试网络连接
curl -v https://api.openai.com/v1/models

# 2. 检查DNS解析
nslookup api.openai.com
dig api.openai.com

# 3. 检查代理设置
echo $http_proxy
echo $https_proxy
echo $no_proxy

# 4. 检查防火墙
sudo iptables -L -n
sudo ufw status
```

**解决方法**：
```bash
# 配置代理（如果需要）
export http_proxy=http://proxy.example.com:8080
export https_proxy=http://proxy.example.com:8080

# 或绕过代理
export no_proxy=localhost,127.0.0.1,.example.com
```

### 存储问题诊断

#### 症状：磁盘空间不足

**诊断步骤**：
```bash
# 1. 检查磁盘使用
df -h

# 2. 查找大文件
du -sh ~/.openclaw/*
du -ah ~/.openclaw | sort -rh | head -20

# 3. 检查日志文件大小
ls -lh ~/.openclaw/logs/

# 4. 检查备份文件
ls -lh ~/.openclaw/backups/
```

**清理建议**：
```bash
# 清理旧日志
find ~/.openclaw/logs -name "*.log" -mtime +7 -delete

# 清理旧备份
find ~/.openclaw/backups -name "*.tar.gz" -mtime +30 -delete

# 清理临时文件
rm -rf ~/.openclaw/tmp/*
```

## 日志分析

### 日志文件位置

```
~/.openclaw/logs/
├── openclaw.log      # 主日志
├── gateway.log       # 网关日志
├── channels.log      # 通道日志
├── skills.log        # 技能日志
├── cron.log          # 任务日志
└── memory.log        # 内存日志
```

### 日志级别

| 级别 | 描述 | 用途 |
|------|------|------|
| error | 错误信息 | 关键问题诊断 |
| warn | 警告信息 | 潜在问题预警 |
| info | 一般信息 | 正常操作记录 |
| debug | 调试信息 | 详细问题诊断 |
| trace | 跟踪信息 | 性能分析 |

### 日志分析命令

```bash
# 查看错误日志
grep -i error ~/.openclaw/logs/openclaw.log

# 查看最近100行
tail -100 ~/.openclaw/logs/openclaw.log

# 实时监控
tail -f ~/.openclaw/logs/openclaw.log

# 按时间过滤
grep "2026-03-26" ~/.openclaw/logs/openclaw.log

# 统计错误数量
grep -c "ERROR" ~/.openclaw/logs/openclaw.log
```

## 调试工具

### 内置调试命令

```bash
# 启用调试模式
OPENCLAW_LOG_LEVEL=debug openclaw dev

# 详细模式
OPENCLAW_DEBUG=1 openclaw dev

# 性能分析
OPENCLAW_PROFILE=1 openclaw dev
```

### 外部调试工具

#### 使用curl测试API
```bash
# 测试健康端点
curl -v http://localhost:3000/health

# 测试认证
curl -H "Authorization: Bearer $TOKEN" \
  http://localhost:3000/api/status

# 测试Webhook
curl -X POST \
  -H "Content-Type: application/json" \
  -d '{"message":"test"}' \
  http://localhost:3000/webhook/telegram
```

#### 使用jq分析JSON
```bash
# 格式化JSON输出
openclaw status | jq .

# 提取特定字段
openclaw status | jq '.version'

# 过滤和搜索
openclaw cron list | jq '.jobs[] | select(.enabled==true)'
```

## 恢复步骤

### 服务无法启动

1. **检查错误信息**
   ```bash
   openclaw start 2>&1 | tee startup.log
   ```

2. **回滚配置**
   ```bash
   cp ~/.openclaw/config.json.backup ~/.openclaw/config.json
   ```

3. **清理状态**
   ```bash
   rm -rf ~/.openclaw/state/*
   ```

4. **最小化启动**
   ```bash
   openclaw --minimal start
   ```

### 数据损坏

1. **从备份恢复**
   ```bash
   openclaw workspace restore --backup latest-backup.tar.gz
   ```

2. **修复数据库**
   ```bash
   openclaw db repair
   ```

3. **重建索引**
   ```bash
   openclaw memory reindex
   openclaw skills rebuild
   ```

### 安全事件

1. **立即停止服务**
   ```bash
   openclaw stop
   ```

2. **更改凭据**
   ```bash
   # 更改API密钥
   # 更改数据库密码
   # 撤销访问令牌
   ```

3. **审计日志**
   ```bash
   grep -i "unauthorized\|failed\|error" ~/.openclaw/logs/*.log
   ```

4. **更新和加固**
   ```bash
   npm update -g openclaw
   openclaw security audit
   ```

## 预防措施

### 定期维护

```bash
# 每日检查
openclaw health check

# 每周备份
openclaw workspace backup

# 每月清理
openclaw workspace cleanup --older-than 30d

# 季度审计
openclaw security audit
```

### 监控配置

```json
{
  "monitoring": {
    "enabled": true,
    "checks": [
      {
        "name": "磁盘空间",
        "type": "disk",
        "threshold": 80,
        "interval": 300
      },
      {
        "name": "内存使用",
        "type": "memory",
        "threshold": 90,
        "interval": 300
      },
      {
        "name": "服务健康",
        "type": "service",
        "endpoints": ["/health", "/api/status"],
        "interval": 60
      }
    ],
    "alerts": {
      "channels": ["telegram", "email"],
      "cooldown": 300
    }
  }
}
```

### 备份策略

```bash
#!/bin/bash
# backup-script.sh

# 每日备份
BACKUP_DIR=~/.openclaw/backups/daily
mkdir -p $BACKUP_DIR
tar -czf $BACKUP_DIR/backup-$(date +%Y%m%d).tar.gz ~/.openclaw/workspace

# 保留最近7天
find $BACKUP_DIR -name "*.tar.gz" -mtime +7 -delete

# 每周完整备份（周日）
if [ $(date +%u) -eq 7 ]; then
  WEEKLY_DIR=~/.openclaw/backups/weekly
  mkdir -p $WEEKLY_DIR
  cp $BACKUP_DIR/backup-$(date +%Y%m%d).tar.gz $WEEKLY_DIR/
  
  # 保留最近4周
  find $WEEKLY_DIR -name "*.tar.gz" -mtime +28 -delete
fi
```

## 获取帮助

### 官方资源

1. **文档网站**: https://docs.openclaw.ai
2. **GitHub仓库**: https://github.com/openclaw/openclaw
3. **社区Discord**: https://discord.com/invite/clawd
4. **问题追踪**: https://github.com/openclaw/openclaw/issues

### 提交问题

提供以下信息有助于快速诊断：
- OpenClaw版本：`openclaw --version`
- 操作系统信息：`uname -a`
- Node.js版本：`node --version`
- 错误日志：相关日志片段
-