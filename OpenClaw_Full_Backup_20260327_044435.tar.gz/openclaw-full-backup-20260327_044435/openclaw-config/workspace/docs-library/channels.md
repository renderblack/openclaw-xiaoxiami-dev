# 聊天通道配置

OpenClaw支持多种聊天平台作为通信通道，每个通道都有独立的配置选项。

## 通道概览

### 支持的通道类型

| 通道 | 状态 | 特点 | 适用场景 |
|------|------|------|----------|
| Telegram | ✅ 稳定 | 个人/群组聊天，文件支持 | 个人助手，小团队 |
| Discord | ✅ 稳定 | 服务器/频道，丰富功能 | 社区，游戏团队 |
| WhatsApp | ✅ 稳定 | 个人聊天，广泛使用 | 个人通讯 |
| Signal | ✅ 稳定 | 端到端加密，隐私强 | 安全敏感场景 |
| Slack | 🔄 测试中 | 工作协作，集成丰富 | 工作团队 |
| Matrix | 🔄 测试中 | 去中心化，开源 | 技术社区 |
| Web Chat | ✅ 稳定 | 浏览器界面，简单易用 | 快速测试 |

## Telegram 配置

### 1. 创建机器人

1. 在Telegram中搜索 @BotFather
2. 发送 `/newbot` 命令
3. 按照提示设置机器人名称和用户名
4. 保存API令牌

### 2. 基本配置

```json
{
  "channels": {
    "telegram": {
      "enabled": true,
      "token": "YOUR_BOT_TOKEN",
      "polling": {
        "interval": 300,
        "timeout": 60
      }
    }
  }
}
```

### 3. 高级配置

```json
{
  "channels": {
    "telegram": {
      "enabled": true,
      "token": "YOUR_BOT_TOKEN",
      "allowedUsers": ["1022202630", "123456789"],
      "allowedGroups": ["-1001234567890"],
      "webhook": {
        "enabled": false,
        "url": "https://your-domain.com/webhook",
        "port": 8443
      },
      "features": {
        "fileUpload": true,
        "voiceMessages": true,
        "inlineButtons": true
      }
    }
  }
}
```

### 4. Webhook模式（生产环境推荐）

```bash
# 设置Webhook
openclaw telegram set-webhook --url https://your-domain.com/webhook

# 删除Webhook
openclaw telegram delete-webhook
```

## Discord 配置

### 1. 创建Discord应用

1. 访问 [Discord开发者门户](https://discord.com/developers/applications)
2. 创建新应用
3. 在"Bot"标签页创建机器人
4. 复制令牌

### 2. 基本配置

```json
{
  "channels": {
    "discord": {
      "enabled": true,
      "token": "YOUR_DISCORD_TOKEN",
      "clientId": "YOUR_CLIENT_ID",
      "intents": ["GUILDS", "GUILD_MESSAGES", "DIRECT_MESSAGES"]
    }
  }
}
```

### 3. 权限配置

```json
{
  "channels": {
    "discord": {
      "enabled": true,
      "token": "YOUR_DISCORD_TOKEN",
      "allowedGuilds": ["123456789012345678"],
      "allowedChannels": ["123456789012345679"],
      "permissions": {
        "readMessages": true,
        "sendMessages": true,
        "embedLinks": true,
        "attachFiles": true,
        "readMessageHistory": true,
        "useExternalEmojis": true
      }
    }
  }
}
```

### 4. 邀请链接

生成机器人邀请链接：
```
https://discord.com/oauth2/authorize?client_id=YOUR_CLIENT_ID&permissions=8&scope=bot%20applications.commands
```

## WhatsApp 配置

### 1. 配置要求

- 需要WhatsApp Business账户
- 需要Meta开发者账户
- 需要验证业务

### 2. 基本配置

```json
{
  "channels": {
    "whatsapp": {
      "enabled": true,
      "phoneNumberId": "YOUR_PHONE_NUMBER_ID",
      "businessAccountId": "YOUR_BUSINESS_ACCOUNT_ID",
      "accessToken": "YOUR_ACCESS_TOKEN",
      "webhookVerifyToken": "YOUR_VERIFY_TOKEN"
    }
  }
}
```

### 3. Webhook配置

```json
{
  "channels": {
    "whatsapp": {
      "enabled": true,
      "webhook": {
        "url": "https://your-domain.com/whatsapp-webhook",
        "verifyToken": "YOUR_VERIFY_TOKEN",
        "fields": ["messages", "statuses"]
      }
    }
  }
}
```

## Signal 配置

### 1. 配置要求

- 需要Signal账户和电话号码
- 需要libsignal-service-java库

### 2. 基本配置

```json
{
  "channels": {
    "signal": {
      "enabled": true,
      "phoneNumber": "+1234567890",
      "server": "https://chat.signal.org",
      "storagePath": "~/.openclaw/signal-storage"
    }
  }
}
```

## Web Chat 配置

### 1. 基本配置

```json
{
  "channels": {
    "web": {
      "enabled": true,
      "port": 8080,
      "auth": {
        "enabled": false,
        "username": "admin",
        "password": "password"
      },
      "features": {
        "fileUpload": true,
        "voiceInput": false,
        "themes": ["light", "dark"]
      }
    }
  }
}
```

### 2. 访问Web界面

```
http://localhost:8080
```

## 多通道管理

### 1. 同时启用多个通道

```json
{
  "channels": {
    "telegram": {
      "enabled": true,
      "token": "TELEGRAM_TOKEN"
    },
    "discord": {
      "enabled": true,
      "token": "DISCORD_TOKEN"
    },
    "web": {
      "enabled": true,
      "port": 8080
    }
  }
}
```

### 2. 通道优先级

```json
{
  "channels": {
    "telegram": {
      "enabled": true,
      "priority": 1
    },
    "discord": {
      "enabled": true,
      "priority": 2
    }
  },
  "routing": {
    "defaultChannel": "telegram",
    "fallbackChannel": "discord"
  }
}
```

## 消息路由

### 1. 基于用户的路由

```json
{
  "routing": {
    "rules": [
      {
        "user": "1022202630",
        "channels": ["telegram", "web"]
      },
      {
        "group": "team-alpha",
        "channel": "discord"
      }
    ]
  }
}
```

### 2. 基于内容的路由

```json
{
  "routing": {
    "rules": [
      {
        "contains": "紧急",
        "channel": "telegram",
        "priority": "high"
      },
      {
        "contains": "代码",
        "channel": "discord",
        "thread": "code-review"
      }
    ]
  }
}
```

## 通道状态监控

### 1. 检查通道状态

```bash
# 查看所有通道状态
openclaw channels status

# 查看特定通道状态
openclaw telegram status
openclaw discord status
```

### 2. 通道日志

```bash
# 查看通道日志
openclaw channels logs --channel telegram

# 实时监控
openclaw channels logs --channel discord --follow
```

## 故障排除

### 常见问题

1. **Telegram机器人无响应**
   - 检查API令牌是否正确
   - 验证机器人是否已启动
   - 检查网络连接

2. **Discord权限问题**
   - 验证机器人权限
   - 检查频道访问权限
   - 确认意图配置

3. **Webhook验证失败**
   - 检查URL可访问性
   - 验证令牌匹配
   - 检查HTTPS配置

### 调试命令

```bash
# 测试通道连接
openclaw channels test --channel telegram

# 发送测试消息
openclaw channels send --channel telegram --to "1022202630" --message "测试消息"

# 重置通道
openclaw channels reset --channel discord
```

## 最佳实践

1. **生产环境使用Webhook**：避免轮询延迟和限制
2. **限制访问权限**：只允许信任的用户和群组
3. **启用日志记录**：便于问题排查
4. **定期备份配置**：防止配置丢失
5. **监控通道健康**：设置健康检查