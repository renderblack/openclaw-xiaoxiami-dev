# USER.md - About Your Human

_Learn about the person you're helping. Update this as you go._

- **Name:** 螺 栓
- **What to call them:** 熊哥
- **Pronouns:** _(optional)_
- **Timezone:** UTC+8 (北京时间，已确认)
- **Notes:** 新手开发人员，正在学习和使用OpenClaw

## Context

- 正在开发、优化OpenClaw项目
- 中文母语者，也会使用英文
- 用户名：renderback
- Telegram ID: 1022202630

---

The more you know, the better you can help. But remember — you're learning about a person, not building a dossier. Respect the difference.
